CRYPTIS "Cryptis" Software is licensed under the CRYPTIS License

Instructions For Use

Power On Unit
Selector Switch "CHARGE" To Position "Standby"
Enter In (6-Digit) ID Code
Touch Card to Scanner

Please avoid ####### and using ######## with the unit.

